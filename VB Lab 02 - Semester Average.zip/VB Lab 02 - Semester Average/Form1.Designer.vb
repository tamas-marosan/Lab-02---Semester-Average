﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SemesterAverageForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SemesterAverageForm))
        Me.txtPercentA = New System.Windows.Forms.TextBox()
        Me.lblGradeA = New System.Windows.Forms.Label()
        Me.lblGradeB = New System.Windows.Forms.Label()
        Me.txtPercentB = New System.Windows.Forms.TextBox()
        Me.lblGradeC = New System.Windows.Forms.Label()
        Me.txtPercentC = New System.Windows.Forms.TextBox()
        Me.lblGradeD = New System.Windows.Forms.Label()
        Me.txtPercentD = New System.Windows.Forms.TextBox()
        Me.lblGradeE = New System.Windows.Forms.Label()
        Me.txtPercentE = New System.Windows.Forms.TextBox()
        Me.lblGradeF = New System.Windows.Forms.Label()
        Me.txtPercentF = New System.Windows.Forms.TextBox()
        Me.lblCourseA = New System.Windows.Forms.Label()
        Me.lblCourseB = New System.Windows.Forms.Label()
        Me.lblCourseC = New System.Windows.Forms.Label()
        Me.lblCourseD = New System.Windows.Forms.Label()
        Me.lblCourseE = New System.Windows.Forms.Label()
        Me.lblCourseF = New System.Windows.Forms.Label()
        Me.lblSem = New System.Windows.Forms.Label()
        Me.lblGradeSem = New System.Windows.Forms.Label()
        Me.lblPercentSem = New System.Windows.Forms.Label()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtPercentA
        '
        Me.txtPercentA.Location = New System.Drawing.Point(67, 6)
        Me.txtPercentA.Name = "txtPercentA"
        Me.txtPercentA.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentA.TabIndex = 1
        Me.txtPercentA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblGradeA
        '
        Me.lblGradeA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeA.Location = New System.Drawing.Point(153, 6)
        Me.lblGradeA.Name = "lblGradeA"
        Me.lblGradeA.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeA.TabIndex = 2
        Me.lblGradeA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGradeB
        '
        Me.lblGradeB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeB.Location = New System.Drawing.Point(153, 32)
        Me.lblGradeB.Name = "lblGradeB"
        Me.lblGradeB.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeB.TabIndex = 5
        Me.lblGradeB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPercentB
        '
        Me.txtPercentB.Location = New System.Drawing.Point(67, 32)
        Me.txtPercentB.Name = "txtPercentB"
        Me.txtPercentB.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentB.TabIndex = 4
        Me.txtPercentB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblGradeC
        '
        Me.lblGradeC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeC.Location = New System.Drawing.Point(153, 58)
        Me.lblGradeC.Name = "lblGradeC"
        Me.lblGradeC.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeC.TabIndex = 8
        Me.lblGradeC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPercentC
        '
        Me.txtPercentC.Location = New System.Drawing.Point(67, 58)
        Me.txtPercentC.Name = "txtPercentC"
        Me.txtPercentC.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentC.TabIndex = 7
        Me.txtPercentC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblGradeD
        '
        Me.lblGradeD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeD.Location = New System.Drawing.Point(153, 84)
        Me.lblGradeD.Name = "lblGradeD"
        Me.lblGradeD.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeD.TabIndex = 11
        Me.lblGradeD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPercentD
        '
        Me.txtPercentD.Location = New System.Drawing.Point(67, 84)
        Me.txtPercentD.Name = "txtPercentD"
        Me.txtPercentD.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentD.TabIndex = 10
        Me.txtPercentD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblGradeE
        '
        Me.lblGradeE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeE.Location = New System.Drawing.Point(153, 110)
        Me.lblGradeE.Name = "lblGradeE"
        Me.lblGradeE.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeE.TabIndex = 14
        Me.lblGradeE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPercentE
        '
        Me.txtPercentE.Location = New System.Drawing.Point(67, 110)
        Me.txtPercentE.Name = "txtPercentE"
        Me.txtPercentE.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentE.TabIndex = 13
        Me.txtPercentE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblGradeF
        '
        Me.lblGradeF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeF.Location = New System.Drawing.Point(153, 136)
        Me.lblGradeF.Name = "lblGradeF"
        Me.lblGradeF.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeF.TabIndex = 17
        Me.lblGradeF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPercentF
        '
        Me.txtPercentF.Location = New System.Drawing.Point(67, 136)
        Me.txtPercentF.Name = "txtPercentF"
        Me.txtPercentF.Size = New System.Drawing.Size(80, 20)
        Me.txtPercentF.TabIndex = 16
        Me.txtPercentF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblCourseA
        '
        Me.lblCourseA.AutoSize = True
        Me.lblCourseA.Location = New System.Drawing.Point(12, 9)
        Me.lblCourseA.Name = "lblCourseA"
        Me.lblCourseA.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseA.TabIndex = 0
        Me.lblCourseA.Text = "Course &1:"
        Me.lblCourseA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourseB
        '
        Me.lblCourseB.AutoSize = True
        Me.lblCourseB.Location = New System.Drawing.Point(12, 35)
        Me.lblCourseB.Name = "lblCourseB"
        Me.lblCourseB.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseB.TabIndex = 3
        Me.lblCourseB.Text = "Course &2:"
        Me.lblCourseB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourseC
        '
        Me.lblCourseC.AutoSize = True
        Me.lblCourseC.Location = New System.Drawing.Point(12, 61)
        Me.lblCourseC.Name = "lblCourseC"
        Me.lblCourseC.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseC.TabIndex = 6
        Me.lblCourseC.Text = "Course &3:"
        Me.lblCourseC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourseD
        '
        Me.lblCourseD.AutoSize = True
        Me.lblCourseD.Location = New System.Drawing.Point(12, 87)
        Me.lblCourseD.Name = "lblCourseD"
        Me.lblCourseD.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseD.TabIndex = 9
        Me.lblCourseD.Text = "Course &4:"
        Me.lblCourseD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourseE
        '
        Me.lblCourseE.AutoSize = True
        Me.lblCourseE.Location = New System.Drawing.Point(12, 113)
        Me.lblCourseE.Name = "lblCourseE"
        Me.lblCourseE.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseE.TabIndex = 12
        Me.lblCourseE.Text = "Course &5:"
        Me.lblCourseE.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourseF
        '
        Me.lblCourseF.AutoSize = True
        Me.lblCourseF.Location = New System.Drawing.Point(12, 139)
        Me.lblCourseF.Name = "lblCourseF"
        Me.lblCourseF.Size = New System.Drawing.Size(52, 13)
        Me.lblCourseF.TabIndex = 15
        Me.lblCourseF.Text = "Course &6:"
        Me.lblCourseF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSem
        '
        Me.lblSem.AutoSize = True
        Me.lblSem.Location = New System.Drawing.Point(10, 165)
        Me.lblSem.Name = "lblSem"
        Me.lblSem.Size = New System.Drawing.Size(54, 13)
        Me.lblSem.TabIndex = 18
        Me.lblSem.Text = "Semester:"
        Me.lblSem.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGradeSem
        '
        Me.lblGradeSem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGradeSem.Location = New System.Drawing.Point(153, 162)
        Me.lblGradeSem.Name = "lblGradeSem"
        Me.lblGradeSem.Size = New System.Drawing.Size(80, 20)
        Me.lblGradeSem.TabIndex = 20
        Me.lblGradeSem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPercentSem
        '
        Me.lblPercentSem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPercentSem.Location = New System.Drawing.Point(67, 162)
        Me.lblPercentSem.Name = "lblPercentSem"
        Me.lblPercentSem.Size = New System.Drawing.Size(80, 20)
        Me.lblPercentSem.TabIndex = 19
        Me.lblPercentSem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOutput
        '
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Location = New System.Drawing.Point(5, 187)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(228, 173)
        Me.lblOutput.TabIndex = 21
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(158, 363)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(81, 363)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(4, 363)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'SemesterAverageForm
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(238, 391)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.lblPercentSem)
        Me.Controls.Add(Me.lblSem)
        Me.Controls.Add(Me.lblGradeSem)
        Me.Controls.Add(Me.lblCourseF)
        Me.Controls.Add(Me.lblCourseE)
        Me.Controls.Add(Me.lblCourseD)
        Me.Controls.Add(Me.lblCourseC)
        Me.Controls.Add(Me.lblCourseB)
        Me.Controls.Add(Me.lblCourseA)
        Me.Controls.Add(Me.lblGradeF)
        Me.Controls.Add(Me.txtPercentA)
        Me.Controls.Add(Me.lblGradeE)
        Me.Controls.Add(Me.txtPercentB)
        Me.Controls.Add(Me.lblGradeD)
        Me.Controls.Add(Me.txtPercentC)
        Me.Controls.Add(Me.lblGradeC)
        Me.Controls.Add(Me.txtPercentD)
        Me.Controls.Add(Me.lblGradeB)
        Me.Controls.Add(Me.txtPercentE)
        Me.Controls.Add(Me.lblGradeA)
        Me.Controls.Add(Me.txtPercentF)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(254, 430)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(254, 430)
        Me.Name = "SemesterAverageForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Grade Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtPercentA As TextBox
    Friend WithEvents lblGradeA As Label
    Friend WithEvents lblGradeB As Label
    Friend WithEvents txtPercentB As TextBox
    Friend WithEvents lblGradeC As Label
    Friend WithEvents txtPercentC As TextBox
    Friend WithEvents lblGradeD As Label
    Friend WithEvents txtPercentD As TextBox
    Friend WithEvents lblGradeE As Label
    Friend WithEvents txtPercentE As TextBox
    Friend WithEvents lblGradeF As Label
    Friend WithEvents txtPercentF As TextBox
    Friend WithEvents lblCourseA As Label
    Friend WithEvents lblCourseB As Label
    Friend WithEvents lblCourseC As Label
    Friend WithEvents lblCourseD As Label
    Friend WithEvents lblCourseE As Label
    Friend WithEvents lblCourseF As Label
    Friend WithEvents lblSem As Label
    Friend WithEvents lblGradeSem As Label
    Friend WithEvents lblPercentSem As Label
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnCalculate As Button
End Class
